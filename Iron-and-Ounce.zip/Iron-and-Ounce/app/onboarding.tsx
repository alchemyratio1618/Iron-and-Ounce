import React, { useState, useRef } from 'react';
import { StyleSheet, Text, View, TextInput, Pressable, ScrollView, Platform, Dimensions, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Svg, { Circle } from 'react-native-svg';
import Colors from '@/constants/colors';
import { useData } from '@/lib/DataContext';
import { UserProfile } from '@/lib/types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface StepConfig {
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
  fields: {
    key: keyof UserProfile;
    label: string;
    placeholder: string;
    unit: string;
    hint?: string;
  }[];
}

const STEPS: StepConfig[] = [
  {
    title: 'Your Body',
    subtitle: 'Where are you starting from?',
    icon: 'body-outline',
    fields: [
      { key: 'currentWeight', label: 'Current Weight', placeholder: '180', unit: 'lbs', hint: 'Step on the scale today' },
      { key: 'goalWeight', label: 'Goal Weight', placeholder: '165', unit: 'lbs', hint: 'What weight are you working toward?' },
    ],
  },
  {
    title: 'Calorie Budget',
    subtitle: 'How much fuel per day?',
    icon: 'flame-outline',
    fields: [
      { key: 'maintenanceCalories', label: 'Daily Calories', placeholder: '2200', unit: 'kcal', hint: 'Your daily calorie target' },
    ],
  },
  {
    title: 'Macro Targets',
    subtitle: 'Dial in your macros',
    icon: 'nutrition-outline',
    fields: [
      { key: 'proteinGoal', label: 'Protein', placeholder: '140', unit: 'g', hint: '100g+ earns Gold status' },
      { key: 'carbsGoal', label: 'Carbs', placeholder: '200', unit: 'g' },
      { key: 'fatsGoal', label: 'Fats', placeholder: '70', unit: 'g' },
    ],
  },
  {
    title: 'Hydration',
    subtitle: 'Stay fueled with water',
    icon: 'water-outline',
    fields: [
      { key: 'waterGoalOz', label: 'Daily Water', placeholder: '100', unit: 'oz', hint: 'How many ounces per day?' },
    ],
  },
];

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const { completeOnboarding } = useData();
  const [step, setStep] = useState(0);
  const [values, setValues] = useState<Record<string, string>>({});

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const webBottomInset = Platform.OS === 'web' ? 34 : 0;

  const currentStep = STEPS[step];
  const isLastStep = step === STEPS.length - 1;
  const isFirstStep = step === 0;

  const updateValue = (key: string, val: string) => {
    setValues(prev => ({ ...prev, [key]: val }));
  };

  const currentFieldsFilled = currentStep.fields.every(f => {
    const v = values[f.key];
    return v && parseFloat(v) > 0;
  });

  const handleNext = () => {
    if (isLastStep) {
      handleFinish();
    } else {
      setStep(s => s + 1);
    }
  };

  const handleBack = () => {
    if (!isFirstStep) setStep(s => s - 1);
  };

  const handleFinish = async () => {
    const currentWeight = parseFloat(values.currentWeight) || 0;
    const profile: UserProfile = {
      currentWeight,
      goalWeight: parseFloat(values.goalWeight) || 0,
      startWeight: currentWeight,
      maintenanceCalories: parseInt(values.maintenanceCalories) || 0,
      proteinGoal: parseInt(values.proteinGoal) || 0,
      carbsGoal: parseInt(values.carbsGoal) || 0,
      fatsGoal: parseInt(values.fatsGoal) || 0,
      waterGoalOz: parseInt(values.waterGoalOz) || 0,
    };
    await completeOnboarding(profile);
  };

  const progressRingSize = 48;
  const progressStroke = 3;
  const progressRadius = (progressRingSize - progressStroke) / 2;
  const progressCircumference = 2 * Math.PI * progressRadius;
  const progressFraction = (step + 1) / STEPS.length;
  const progressOffset = progressCircumference * (1 - progressFraction);

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.dark.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + webTopInset + 20, paddingBottom: insets.bottom + webBottomInset + 40 },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.topBar}>
          {!isFirstStep ? (
            <Pressable onPress={handleBack} style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]} hitSlop={12}>
              <Ionicons name="arrow-back" size={22} color={Colors.dark.textSecondary} />
            </Pressable>
          ) : (
            <View style={{ width: 42 }} />
          )}

          <View style={styles.progressRingContainer}>
            <Svg width={progressRingSize} height={progressRingSize}>
              <Circle
                cx={progressRingSize / 2}
                cy={progressRingSize / 2}
                r={progressRadius}
                stroke={Colors.dark.border}
                strokeWidth={progressStroke}
                fill="none"
              />
              <Circle
                cx={progressRingSize / 2}
                cy={progressRingSize / 2}
                r={progressRadius}
                stroke={Colors.dark.gold}
                strokeWidth={progressStroke}
                fill="none"
                strokeDasharray={`${progressCircumference}`}
                strokeDashoffset={progressOffset}
                strokeLinecap="round"
                transform={`rotate(-90 ${progressRingSize / 2} ${progressRingSize / 2})`}
              />
            </Svg>
            <Text style={styles.progressText}>{step + 1}/{STEPS.length}</Text>
          </View>

          <View style={{ width: 42 }} />
        </View>

        <View style={styles.heroSection}>
          <View style={styles.iconCircle}>
            <Ionicons name={currentStep.icon} size={36} color={Colors.dark.gold} />
          </View>
          <Text style={styles.stepTitle}>{currentStep.title}</Text>
          <Text style={styles.stepSubtitle}>{currentStep.subtitle}</Text>
        </View>

        <View style={styles.fieldsContainer}>
          {currentStep.fields.map((field) => (
            <View key={field.key} style={styles.fieldCard}>
              <Text style={styles.fieldLabel}>{field.label}</Text>
              <View style={styles.inputRow}>
                <TextInput
                  style={styles.input}
                  placeholder={field.placeholder}
                  placeholderTextColor={Colors.dark.textMuted}
                  keyboardType="numeric"
                  value={values[field.key] || ''}
                  onChangeText={(val) => updateValue(field.key, val)}
                  testID={`onboarding-input-${field.key}`}
                />
                <View style={styles.unitBadge}>
                  <Text style={styles.unitText}>{field.unit}</Text>
                </View>
              </View>
              {field.hint && <Text style={styles.fieldHint}>{field.hint}</Text>}
            </View>
          ))}
        </View>

        <Pressable
          style={({ pressed }) => [
            styles.continueBtn,
            !currentFieldsFilled && styles.continueBtnDisabled,
            pressed && currentFieldsFilled && { opacity: 0.85 },
          ]}
          onPress={handleNext}
          disabled={!currentFieldsFilled}
          testID="onboarding-continue"
        >
          <Text style={[styles.continueBtnText, !currentFieldsFilled && styles.continueBtnTextDisabled]}>
            {isLastStep ? 'Start Tracking' : 'Continue'}
          </Text>
          <Ionicons
            name={isLastStep ? 'checkmark' : 'arrow-forward'}
            size={20}
            color={currentFieldsFilled ? '#0A0A0F' : Colors.dark.textMuted}
          />
        </Pressable>

        {step === 0 && (
          <Text style={styles.disclaimer}>
            You can always change these later in the Progress tab.
          </Text>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  content: {
    paddingHorizontal: 24,
    flexGrow: 1,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 32,
  },
  backBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.dark.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressRingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressText: {
    position: 'absolute',
    color: Colors.dark.textSecondary,
    fontSize: 12,
    fontFamily: 'Rubik_500Medium',
  },
  heroSection: {
    alignItems: 'center',
    marginBottom: 36,
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.dark.surfaceElevated,
    borderWidth: 1,
    borderColor: Colors.dark.gold + '40',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  stepTitle: {
    color: Colors.dark.text,
    fontSize: 28,
    fontFamily: 'Rubik_700Bold',
    letterSpacing: -0.5,
    marginBottom: 6,
  },
  stepSubtitle: {
    color: Colors.dark.textSecondary,
    fontSize: 15,
    fontFamily: 'Rubik_400Regular',
  },
  fieldsContainer: {
    gap: 14,
    marginBottom: 32,
  },
  fieldCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  fieldLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 12,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  input: {
    flex: 1,
    backgroundColor: Colors.dark.surfaceElevated,
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 14,
    color: Colors.dark.text,
    fontSize: 24,
    fontFamily: 'Rubik_600SemiBold',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  unitBadge: {
    backgroundColor: Colors.dark.surfaceHighlight,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  unitText: {
    color: Colors.dark.textSecondary,
    fontSize: 15,
    fontFamily: 'Rubik_500Medium',
  },
  fieldHint: {
    color: Colors.dark.textMuted,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
    marginTop: 10,
  },
  continueBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.dark.gold,
    borderRadius: 14,
    paddingVertical: 16,
    marginBottom: 16,
  },
  continueBtnDisabled: {
    backgroundColor: Colors.dark.surfaceElevated,
  },
  continueBtnText: {
    color: '#0A0A0F',
    fontSize: 17,
    fontFamily: 'Rubik_600SemiBold',
  },
  continueBtnTextDisabled: {
    color: Colors.dark.textMuted,
  },
  disclaimer: {
    color: Colors.dark.textMuted,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
    textAlign: 'center',
  },
});
