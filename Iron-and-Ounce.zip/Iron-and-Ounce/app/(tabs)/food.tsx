import React, { useState, useCallback } from 'react';
import { StyleSheet, Text, View, ScrollView, Pressable, TextInput, FlatList, Platform, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useData } from '@/lib/DataContext';
import { COMMON_FOODS, FoodEntry } from '@/lib/types';

function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

export default function FoodScreen() {
  const insets = useSafeAreaInsets();
  const { daily, addFood, removeFood, totalCaloriesConsumed, totalProtein, totalCarbs, totalFats } = useData();
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState('');
  const [customName, setCustomName] = useState('');
  const [customCal, setCustomCal] = useState('');
  const [customProtein, setCustomProtein] = useState('');
  const [customCarbs, setCustomCarbs] = useState('');
  const [customFats, setCustomFats] = useState('');
  const [showCustom, setShowCustom] = useState(false);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const filteredFoods = COMMON_FOODS.filter(f =>
    f.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleQuickAdd = useCallback(async (food: typeof COMMON_FOODS[0]) => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const entry: FoodEntry = {
      id: generateId(),
      name: food.name,
      calories: food.calories,
      protein: food.protein,
      carbs: food.carbs,
      fats: food.fats,
      timestamp: Date.now(),
    };
    await addFood(entry);
    setShowAdd(false);
    setSearch('');
  }, [addFood]);

  const handleCustomAdd = useCallback(async () => {
    if (!customName || !customCal) return;
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const entry: FoodEntry = {
      id: generateId(),
      name: customName,
      calories: parseInt(customCal) || 0,
      protein: parseInt(customProtein) || 0,
      carbs: parseInt(customCarbs) || 0,
      fats: parseInt(customFats) || 0,
      timestamp: Date.now(),
    };
    await addFood(entry);
    setShowCustom(false);
    setShowAdd(false);
    setCustomName(''); setCustomCal(''); setCustomProtein(''); setCustomCarbs(''); setCustomFats('');
  }, [addFood, customName, customCal, customProtein, customCarbs, customFats]);

  const handleRemove = useCallback(async (id: string) => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await removeFood(id);
  }, [removeFood]);

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Food Log</Text>
        <Pressable
          style={({ pressed }) => [styles.addButton, pressed && styles.addButtonPressed]}
          onPress={() => { setShowAdd(!showAdd); setShowCustom(false); }}
        >
          <Ionicons name={showAdd ? 'close' : 'add'} size={24} color={Colors.dark.gold} />
        </Pressable>
      </View>

      <View style={styles.summaryRow}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryValue}>{totalCaloriesConsumed}</Text>
          <Text style={styles.summaryLabel}>kcal</Text>
        </View>
        <View style={styles.summaryDivider} />
        <View style={styles.summaryItem}>
          <Text style={[styles.summaryValue, { color: Colors.dark.protein }]}>{totalProtein}g</Text>
          <Text style={styles.summaryLabel}>protein</Text>
        </View>
        <View style={styles.summaryDivider} />
        <View style={styles.summaryItem}>
          <Text style={[styles.summaryValue, { color: Colors.dark.carbs }]}>{totalCarbs}g</Text>
          <Text style={styles.summaryLabel}>carbs</Text>
        </View>
        <View style={styles.summaryDivider} />
        <View style={styles.summaryItem}>
          <Text style={[styles.summaryValue, { color: Colors.dark.fats }]}>{totalFats}g</Text>
          <Text style={styles.summaryLabel}>fats</Text>
        </View>
      </View>

      {showAdd && (
        <View style={styles.addSection}>
          <View style={styles.tabRow}>
            <Pressable
              style={[styles.tab, !showCustom && styles.tabActive]}
              onPress={() => setShowCustom(false)}
            >
              <Text style={[styles.tabText, !showCustom && styles.tabTextActive]}>Common Foods</Text>
            </Pressable>
            <Pressable
              style={[styles.tab, showCustom && styles.tabActive]}
              onPress={() => setShowCustom(true)}
            >
              <Text style={[styles.tabText, showCustom && styles.tabTextActive]}>Custom Entry</Text>
            </Pressable>
          </View>

          {!showCustom ? (
            <View>
              <View style={styles.searchRow}>
                <Feather name="search" size={18} color={Colors.dark.textMuted} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search foods..."
                  placeholderTextColor={Colors.dark.textMuted}
                  value={search}
                  onChangeText={setSearch}
                />
              </View>
              <ScrollView style={styles.foodList} showsVerticalScrollIndicator={false}>
                {filteredFoods.map((food, i) => (
                  <Pressable
                    key={i}
                    style={({ pressed }) => [styles.foodItem, pressed && styles.foodItemPressed]}
                    onPress={() => handleQuickAdd(food)}
                  >
                    <View style={styles.foodItemLeft}>
                      <Text style={styles.foodName}>{food.name}</Text>
                      <Text style={styles.foodMacros}>P:{food.protein}g  C:{food.carbs}g  F:{food.fats}g</Text>
                    </View>
                    <View style={styles.foodItemRight}>
                      <Text style={styles.foodCal}>{food.calories}</Text>
                      <Text style={styles.foodCalLabel}>kcal</Text>
                    </View>
                  </Pressable>
                ))}
              </ScrollView>
            </View>
          ) : (
            <ScrollView style={styles.customForm} showsVerticalScrollIndicator={false}>
              <TextInput
                style={styles.input}
                placeholder="Food name"
                placeholderTextColor={Colors.dark.textMuted}
                value={customName}
                onChangeText={setCustomName}
              />
              <View style={styles.inputRow}>
                <View style={styles.inputHalf}>
                  <Text style={styles.inputLabel}>Calories</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="0"
                    placeholderTextColor={Colors.dark.textMuted}
                    keyboardType="numeric"
                    value={customCal}
                    onChangeText={setCustomCal}
                  />
                </View>
                <View style={styles.inputHalf}>
                  <Text style={styles.inputLabel}>Protein (g)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="0"
                    placeholderTextColor={Colors.dark.textMuted}
                    keyboardType="numeric"
                    value={customProtein}
                    onChangeText={setCustomProtein}
                  />
                </View>
              </View>
              <View style={styles.inputRow}>
                <View style={styles.inputHalf}>
                  <Text style={styles.inputLabel}>Carbs (g)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="0"
                    placeholderTextColor={Colors.dark.textMuted}
                    keyboardType="numeric"
                    value={customCarbs}
                    onChangeText={setCustomCarbs}
                  />
                </View>
                <View style={styles.inputHalf}>
                  <Text style={styles.inputLabel}>Fats (g)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="0"
                    placeholderTextColor={Colors.dark.textMuted}
                    keyboardType="numeric"
                    value={customFats}
                    onChangeText={setCustomFats}
                  />
                </View>
              </View>
              <Pressable
                style={({ pressed }) => [styles.saveButton, pressed && styles.saveButtonPressed, (!customName || !customCal) && styles.saveButtonDisabled]}
                onPress={handleCustomAdd}
                disabled={!customName || !customCal}
              >
                <Ionicons name="checkmark" size={20} color="#0A0A0F" />
                <Text style={styles.saveButtonText}>Add Food</Text>
              </Pressable>
            </ScrollView>
          )}
        </View>
      )}

      {!showAdd && (
        <FlatList
          data={[...daily.foods].reverse()}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.logList}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="restaurant-outline" size={48} color={Colors.dark.textMuted} />
              <Text style={styles.emptyText}>No food logged today</Text>
              <Text style={styles.emptySubtext}>Tap + to add your first meal</Text>
            </View>
          }
          renderItem={({ item }) => (
            <View style={styles.logItem}>
              <View style={styles.logItemLeft}>
                <Text style={styles.logName}>{item.name}</Text>
                <Text style={styles.logMacros}>P:{item.protein}g  C:{item.carbs}g  F:{item.fats}g</Text>
              </View>
              <View style={styles.logItemRight}>
                <Text style={styles.logCal}>{item.calories} kcal</Text>
                <Pressable onPress={() => handleRemove(item.id)} hitSlop={8}>
                  <Ionicons name="trash-outline" size={18} color={Colors.dark.error} />
                </Pressable>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  title: {
    color: Colors.dark.text,
    fontSize: 24,
    fontFamily: 'Rubik_700Bold',
  },
  addButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.dark.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  addButtonPressed: {
    backgroundColor: Colors.dark.surfaceHighlight,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginHorizontal: 20,
    marginBottom: 16,
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryValue: {
    color: Colors.dark.text,
    fontSize: 18,
    fontFamily: 'Rubik_700Bold',
  },
  summaryLabel: {
    color: Colors.dark.textMuted,
    fontSize: 10,
    fontFamily: 'Rubik_400Regular',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginTop: 2,
  },
  summaryDivider: {
    width: 1,
    height: 30,
    backgroundColor: Colors.dark.border,
  },
  addSection: {
    flex: 1,
    paddingHorizontal: 20,
  },
  tabRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 14,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
    backgroundColor: Colors.dark.surface,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  tabActive: {
    backgroundColor: Colors.dark.surfaceHighlight,
    borderColor: Colors.dark.gold,
  },
  tabText: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
  },
  tabTextActive: {
    color: Colors.dark.gold,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dark.surface,
    borderRadius: 10,
    paddingHorizontal: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_400Regular',
    paddingVertical: 12,
  },
  foodList: {
    maxHeight: 350,
  },
  foodItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.dark.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  foodItemPressed: {
    backgroundColor: Colors.dark.surfaceHighlight,
  },
  foodItemLeft: {
    flex: 1,
  },
  foodName: {
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_500Medium',
    marginBottom: 2,
  },
  foodMacros: {
    color: Colors.dark.textMuted,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
  },
  foodItemRight: {
    alignItems: 'flex-end',
  },
  foodCal: {
    color: Colors.dark.gold,
    fontSize: 18,
    fontFamily: 'Rubik_700Bold',
  },
  foodCalLabel: {
    color: Colors.dark.textMuted,
    fontSize: 10,
    fontFamily: 'Rubik_400Regular',
  },
  customForm: {
    maxHeight: 400,
  },
  input: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_400Regular',
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginBottom: 10,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 10,
  },
  inputHalf: {
    flex: 1,
  },
  inputLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 12,
    fontFamily: 'Rubik_500Medium',
    marginBottom: 4,
    marginLeft: 4,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.dark.gold,
    borderRadius: 12,
    paddingVertical: 14,
    marginTop: 6,
  },
  saveButtonPressed: {
    opacity: 0.85,
  },
  saveButtonDisabled: {
    opacity: 0.4,
  },
  saveButtonText: {
    color: '#0A0A0F',
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
  },
  logList: {
    paddingHorizontal: 20,
    paddingBottom: 120,
  },
  logItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.dark.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  logItemLeft: {
    flex: 1,
  },
  logName: {
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_500Medium',
    marginBottom: 2,
  },
  logMacros: {
    color: Colors.dark.textMuted,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
  },
  logItemRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  logCal: {
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_500Medium',
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 80,
    gap: 8,
  },
  emptyText: {
    color: Colors.dark.textSecondary,
    fontSize: 16,
    fontFamily: 'Rubik_500Medium',
    marginTop: 8,
  },
  emptySubtext: {
    color: Colors.dark.textMuted,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
  },
});
