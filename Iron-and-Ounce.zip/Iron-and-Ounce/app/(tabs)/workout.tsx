import React, { useState, useCallback } from 'react';
import { StyleSheet, Text, View, ScrollView, Pressable, TextInput, Platform, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useData } from '@/lib/DataContext';
import {
  ExerciseEntry, ExerciseSet, WorkoutSession, ExerciseType,
  STRENGTH_EXERCISES, CARDIO_EXERCISES, ExerciseCatalogItem,
} from '@/lib/types';

function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

interface SetInput {
  reps: string;
  weight: string;
}

interface CardioInput {
  duration: string;
  calories: string;
  calOverride: string;
}

type ExerciseCategory = 'strength' | 'cardio';

export default function WorkoutScreen() {
  const insets = useSafeAreaInsets();
  const { daily, addWorkout, removeWorkout } = useData();
  const [isActive, setIsActive] = useState(false);
  const [exercises, setExercises] = useState<ExerciseEntry[]>([]);
  const [showExercisePicker, setShowExercisePicker] = useState(false);
  const [customExercise, setCustomExercise] = useState('');
  const [currentSets, setCurrentSets] = useState<{ [exerciseId: string]: SetInput[] }>({});
  const [cardioInputs, setCardioInputs] = useState<{ [exerciseId: string]: CardioInput }>({});
  const [caloriesBurned, setCaloriesBurned] = useState('');
  const [pickerCategory, setPickerCategory] = useState<ExerciseCategory>('strength');
  const [editingWorkoutId, setEditingWorkoutId] = useState<string | null>(null);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const addExercise = useCallback((item: ExerciseCatalogItem) => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const id = generateId();
    const exercise: ExerciseEntry = {
      id,
      name: item.name,
      type: item.type,
      sets: [],
      caloriesBurned: 0,
      timestamp: Date.now(),
    };
    setExercises(prev => [...prev, exercise]);
    if (item.type === 'strength') {
      setCurrentSets(prev => ({ ...prev, [id]: [{ reps: '', weight: '' }] }));
    } else {
      const cpm = item.caloriesPerMin || 8;
      setCardioInputs(prev => ({ ...prev, [id]: { duration: '', calories: String(cpm), calOverride: '' } }));
    }
    setShowExercisePicker(false);
    setCustomExercise('');
  }, []);

  const addCustomExercise = useCallback((name: string, type: ExerciseType) => {
    addExercise({ name, type, caloriesPerMin: type === 'cardio' ? 8 : undefined });
  }, [addExercise]);

  const addSetRow = useCallback((exerciseId: string) => {
    setCurrentSets(prev => ({
      ...prev,
      [exerciseId]: [...(prev[exerciseId] || []), { reps: '', weight: '' }],
    }));
  }, []);

  const updateSetInput = useCallback((exerciseId: string, setIndex: number, field: 'reps' | 'weight', value: string) => {
    setCurrentSets(prev => {
      const sets = [...(prev[exerciseId] || [])];
      sets[setIndex] = { ...sets[setIndex], [field]: value };
      return { ...prev, [exerciseId]: sets };
    });
  }, []);

  const updateCardioInput = useCallback((exerciseId: string, field: 'duration' | 'calories' | 'calOverride', value: string) => {
    setCardioInputs(prev => {
      const current = prev[exerciseId] || { duration: '', calories: '8', calOverride: '' };
      const updated = { ...current, [field]: value };
      if (field === 'duration' || field === 'calories') {
        updated.calOverride = '';
      }
      return { ...prev, [exerciseId]: updated };
    });
  }, []);

  const removeExercise = useCallback((id: string) => {
    setExercises(prev => prev.filter(e => e.id !== id));
    setCurrentSets(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setCardioInputs(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const removeSet = useCallback((exerciseId: string, setIndex: number) => {
    setCurrentSets(prev => {
      const sets = [...(prev[exerciseId] || [])];
      sets.splice(setIndex, 1);
      return { ...prev, [exerciseId]: sets };
    });
  }, []);

  const getCardioCals = useCallback((exId: string) => {
    const input = cardioInputs[exId] || { duration: '0', calories: '8', calOverride: '' };
    if (input.calOverride && parseInt(input.calOverride) > 0) {
      return parseInt(input.calOverride);
    }
    return (parseInt(input.duration) || 0) * (parseInt(input.calories) || 8);
  }, [cardioInputs]);

  const finishWorkout = useCallback(async () => {
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    const finalExercises = exercises.map(ex => {
      if (ex.type === 'cardio') {
        const input = cardioInputs[ex.id] || { duration: '0', calories: '8', calOverride: '' };
        const dur = parseInt(input.duration) || 0;
        const cals = getCardioCals(ex.id);
        return { ...ex, durationMin: dur, caloriesBurned: cals };
      }
      const setInputs = currentSets[ex.id] || [];
      const sets: ExerciseSet[] = setInputs
        .filter(s => s.reps && s.weight)
        .map(s => ({ reps: parseInt(s.reps), weight: parseInt(s.weight) }));
      return { ...ex, sets };
    });

    const totalVolume = finalExercises.reduce((sum, ex) =>
      sum + ex.sets.reduce((s, set) => s + (set.reps * set.weight), 0), 0);

    const cardioCalories = finalExercises
      .filter(e => e.type === 'cardio')
      .reduce((sum, e) => sum + e.caloriesBurned, 0);

    const strengthCalories = parseInt(caloriesBurned) || Math.round(totalVolume * 0.015);

    const totalBurn = cardioCalories + strengthCalories;

    const strengthExercises = finalExercises.filter(e => e.type === 'strength');
    const exercisesWithCalories = finalExercises.map(e => {
      if (e.type === 'cardio') return e;
      const perExercise = strengthExercises.length > 0 ? Math.round(strengthCalories / strengthExercises.length) : 0;
      return { ...e, caloriesBurned: perExercise };
    });

    const workout: WorkoutSession = {
      id: editingWorkoutId || generateId(),
      date: new Date().toISOString().split('T')[0],
      exercises: exercisesWithCalories,
      totalVolume,
      totalCaloriesBurned: totalBurn,
    };

    await addWorkout(workout);
    resetSession();
  }, [exercises, currentSets, cardioInputs, caloriesBurned, addWorkout, editingWorkoutId]);

  const resetSession = () => {
    setIsActive(false);
    setExercises([]);
    setCurrentSets({});
    setCardioInputs({});
    setCaloriesBurned('');
    setEditingWorkoutId(null);
  };

  const handleDeleteWorkout = useCallback(async (id: string) => {
    if (Platform.OS === 'web') {
      if (confirm('Remove this workout session?')) {
        await removeWorkout(id);
      }
    } else {
      Alert.alert('Remove Workout', 'Remove this workout session?', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => removeWorkout(id) },
      ]);
    }
  }, [removeWorkout]);

  const totalVolume = exercises
    .filter(e => e.type === 'strength')
    .reduce((sum, ex) => {
      const setInputs = currentSets[ex.id] || [];
      return sum + setInputs.reduce((s, set) => {
        const r = parseInt(set.reps) || 0;
        const w = parseInt(set.weight) || 0;
        return s + (r * w);
      }, 0);
    }, 0);

  const estimatedCardioCalories = exercises
    .filter(e => e.type === 'cardio')
    .reduce((sum, ex) => sum + getCardioCals(ex.id), 0);

  const currentCatalog = pickerCategory === 'strength' ? STRENGTH_EXERCISES : CARDIO_EXERCISES;

  const getExerciseIcon = (type: ExerciseType) => {
    return type === 'cardio' ? 'run-fast' : 'dumbbell';
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Workout</Text>
        {isActive && (
          <View style={styles.headerActions}>
            <Pressable
              style={({ pressed }) => [styles.cancelSessionBtn, pressed && { opacity: 0.7 }]}
              onPress={resetSession}
            >
              <Ionicons name="close" size={20} color={Colors.dark.textMuted} />
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.finishBtn, pressed && { opacity: 0.85 }]}
              onPress={finishWorkout}
            >
              <Ionicons name="checkmark" size={20} color="#0A0A0F" />
            </Pressable>
          </View>
        )}
      </View>

      {!isActive ? (
        <ScrollView
          contentContainerStyle={styles.inactiveContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.startSection}>
            <View style={styles.startIconRow}>
              <MaterialCommunityIcons name="dumbbell" size={36} color={Colors.dark.gold} />
              <MaterialCommunityIcons name="run-fast" size={36} color={Colors.dark.accent} />
            </View>
            <Text style={styles.startTitle}>Ready to train?</Text>
            <Text style={styles.startSubtitle}>Log lifting, running, treadmill, and more</Text>
            <Pressable
              style={({ pressed }) => [styles.startBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
              onPress={() => {
                if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                setIsActive(true);
              }}
            >
              <Ionicons name="play" size={20} color="#0A0A0F" />
              <Text style={styles.startBtnText}>Start Workout</Text>
            </Pressable>
          </View>

          {daily.workouts.length > 0 && (
            <View style={styles.historySection}>
              <Text style={styles.sectionTitle}>Today's Sessions</Text>
              {daily.workouts.map(w => (
                <View key={w.id} style={styles.historyCard}>
                  <View style={styles.historyHeader}>
                    <Text style={styles.historyTitle}>{w.exercises.length} exercises</Text>
                    <View style={styles.historyActions}>
                      <Text style={styles.historyBurn}>+{w.totalCaloriesBurned} kcal</Text>
                      <Pressable
                        onPress={() => handleDeleteWorkout(w.id)}
                        hitSlop={8}
                        style={styles.historyActionBtn}
                      >
                        <Ionicons name="trash-outline" size={18} color={Colors.dark.error} />
                      </Pressable>
                    </View>
                  </View>
                  {w.exercises.map(ex => (
                    <View key={ex.id} style={styles.historyExercise}>
                      <View style={styles.historyExRow}>
                        <MaterialCommunityIcons
                          name={getExerciseIcon(ex.type || 'strength')}
                          size={16}
                          color={ex.type === 'cardio' ? Colors.dark.accent : Colors.dark.gold}
                        />
                        <Text style={styles.historyExName}>{ex.name}</Text>
                      </View>
                      <Text style={styles.historySets}>
                        {ex.type === 'cardio'
                          ? `${ex.durationMin || 0} min`
                          : `${ex.sets.length} sets`
                        }
                      </Text>
                    </View>
                  ))}
                  {w.totalVolume > 0 && (
                    <Text style={styles.historyVolume}>{w.totalVolume.toLocaleString()} lbs total volume</Text>
                  )}
                </View>
              ))}
            </View>
          )}
        </ScrollView>
      ) : (
        <ScrollView
          contentContainerStyle={styles.activeContent}
          showsVerticalScrollIndicator={false}
        >
          {(totalVolume > 0 || estimatedCardioCalories > 0) && (
            <View style={styles.statsRow}>
              {totalVolume > 0 && (
                <View style={[styles.statCard, { borderColor: Colors.dark.gold }]}>
                  <MaterialCommunityIcons name="dumbbell" size={18} color={Colors.dark.gold} />
                  <Text style={styles.statValue}>{totalVolume.toLocaleString()}</Text>
                  <Text style={styles.statLabel}>lbs volume</Text>
                </View>
              )}
              {estimatedCardioCalories > 0 && (
                <View style={[styles.statCard, { borderColor: Colors.dark.accent }]}>
                  <MaterialCommunityIcons name="fire" size={18} color={Colors.dark.caloriesBurn} />
                  <Text style={[styles.statValue, { color: Colors.dark.caloriesBurn }]}>{estimatedCardioCalories}</Text>
                  <Text style={styles.statLabel}>cal cardio</Text>
                </View>
              )}
            </View>
          )}

          {exercises.map(ex => (
            <View key={ex.id} style={[styles.exerciseCard, ex.type === 'cardio' && styles.cardioCard]}>
              <View style={styles.exerciseHeader}>
                <View style={styles.exerciseNameRow}>
                  <MaterialCommunityIcons
                    name={getExerciseIcon(ex.type)}
                    size={20}
                    color={ex.type === 'cardio' ? Colors.dark.accent : Colors.dark.gold}
                  />
                  <Text style={styles.exerciseName}>{ex.name}</Text>
                  <View style={[styles.typeBadge, ex.type === 'cardio' ? styles.cardioBadge : styles.strengthBadge]}>
                    <Text style={[styles.typeBadgeText, ex.type === 'cardio' ? styles.cardioBadgeText : styles.strengthBadgeText]}>
                      {ex.type === 'cardio' ? 'Cardio' : 'Strength'}
                    </Text>
                  </View>
                </View>
                <Pressable onPress={() => removeExercise(ex.id)} hitSlop={8}>
                  <Ionicons name="close-circle" size={22} color={Colors.dark.error} />
                </Pressable>
              </View>

              {ex.type === 'cardio' ? (
                <View style={styles.cardioFields}>
                  <View style={styles.cardioField}>
                    <Text style={styles.cardioFieldLabel}>Duration (min)</Text>
                    <TextInput
                      style={styles.cardioInput}
                      placeholder="0"
                      placeholderTextColor={Colors.dark.textMuted}
                      keyboardType="numeric"
                      value={cardioInputs[ex.id]?.duration || ''}
                      onChangeText={v => updateCardioInput(ex.id, 'duration', v)}
                    />
                  </View>
                  <View style={styles.cardioField}>
                    <Text style={styles.cardioFieldLabel}>Cal/min</Text>
                    <TextInput
                      style={styles.cardioInput}
                      placeholder="8"
                      placeholderTextColor={Colors.dark.textMuted}
                      keyboardType="numeric"
                      value={cardioInputs[ex.id]?.calories || ''}
                      onChangeText={v => updateCardioInput(ex.id, 'calories', v)}
                    />
                  </View>
                  <View style={styles.cardioField}>
                    <Text style={styles.cardioFieldLabel}>Total cal</Text>
                    <TextInput
                      style={[
                        styles.cardioInput,
                        styles.cardioCalInput,
                        cardioInputs[ex.id]?.calOverride ? styles.cardioCalOverride : null,
                      ]}
                      placeholder={String((parseInt(cardioInputs[ex.id]?.duration) || 0) * (parseInt(cardioInputs[ex.id]?.calories) || 8))}
                      placeholderTextColor={Colors.dark.caloriesBurn}
                      keyboardType="numeric"
                      value={cardioInputs[ex.id]?.calOverride || ''}
                      onChangeText={v => updateCardioInput(ex.id, 'calOverride', v)}
                    />
                  </View>
                </View>
              ) : (
                <>
                  <View style={styles.setHeader}>
                    <Text style={styles.setHeaderText}>Set</Text>
                    <Text style={styles.setHeaderText}>Reps</Text>
                    <Text style={styles.setHeaderText}>Weight (lbs)</Text>
                    <View style={{ width: 24 }} />
                  </View>
                  {(currentSets[ex.id] || []).map((set, i) => (
                    <View key={i} style={styles.setRow}>
                      <Text style={styles.setNumber}>{i + 1}</Text>
                      <TextInput
                        style={styles.setInput}
                        placeholder="0"
                        placeholderTextColor={Colors.dark.textMuted}
                        keyboardType="numeric"
                        value={set.reps}
                        onChangeText={v => updateSetInput(ex.id, i, 'reps', v)}
                      />
                      <TextInput
                        style={styles.setInput}
                        placeholder="0"
                        placeholderTextColor={Colors.dark.textMuted}
                        keyboardType="numeric"
                        value={set.weight}
                        onChangeText={v => updateSetInput(ex.id, i, 'weight', v)}
                      />
                      <Pressable onPress={() => removeSet(ex.id, i)} hitSlop={8}>
                        <Ionicons name="remove-circle-outline" size={20} color={Colors.dark.textMuted} />
                      </Pressable>
                    </View>
                  ))}
                  <Pressable
                    style={({ pressed }) => [styles.addSetBtn, pressed && { opacity: 0.7 }]}
                    onPress={() => addSetRow(ex.id)}
                  >
                    <Ionicons name="add" size={16} color={Colors.dark.accent} />
                    <Text style={styles.addSetText}>Add Set</Text>
                  </Pressable>
                </>
              )}
            </View>
          ))}

          {showExercisePicker ? (
            <View style={styles.pickerCard}>
              <View style={styles.categoryTabs}>
                <Pressable
                  style={[styles.categoryTab, pickerCategory === 'strength' && styles.categoryTabActive]}
                  onPress={() => setPickerCategory('strength')}
                >
                  <MaterialCommunityIcons
                    name="dumbbell"
                    size={16}
                    color={pickerCategory === 'strength' ? '#0A0A0F' : Colors.dark.textSecondary}
                  />
                  <Text style={[styles.categoryTabText, pickerCategory === 'strength' && styles.categoryTabTextActive]}>
                    Strength
                  </Text>
                </Pressable>
                <Pressable
                  style={[styles.categoryTab, pickerCategory === 'cardio' && styles.categoryTabActiveCardio]}
                  onPress={() => setPickerCategory('cardio')}
                >
                  <MaterialCommunityIcons
                    name="run-fast"
                    size={16}
                    color={pickerCategory === 'cardio' ? '#0A0A0F' : Colors.dark.textSecondary}
                  />
                  <Text style={[styles.categoryTabText, pickerCategory === 'cardio' && styles.categoryTabTextActive]}>
                    Cardio
                  </Text>
                </Pressable>
              </View>

              <View style={styles.customRow}>
                <TextInput
                  style={[styles.setInput, { flex: 1 }]}
                  placeholder={`Custom ${pickerCategory} exercise...`}
                  placeholderTextColor={Colors.dark.textMuted}
                  value={customExercise}
                  onChangeText={setCustomExercise}
                />
                {customExercise.length > 0 && (
                  <Pressable
                    style={styles.customAddBtn}
                    onPress={() => addCustomExercise(customExercise, pickerCategory)}
                  >
                    <Ionicons name="add" size={18} color="#0A0A0F" />
                  </Pressable>
                )}
              </View>
              <ScrollView style={styles.exerciseList} showsVerticalScrollIndicator={false}>
                {currentCatalog.map((item, i) => (
                  <Pressable
                    key={i}
                    style={({ pressed }) => [styles.exerciseOption, pressed && { backgroundColor: Colors.dark.surfaceHighlight }]}
                    onPress={() => addExercise(item)}
                  >
                    <View style={styles.exerciseOptionRow}>
                      <Text style={styles.exerciseOptionText}>{item.name}</Text>
                      {item.caloriesPerMin && (
                        <Text style={styles.exerciseOptionMeta}>{item.caloriesPerMin} cal/min</Text>
                      )}
                    </View>
                    <Ionicons
                      name="add-circle-outline"
                      size={20}
                      color={pickerCategory === 'cardio' ? Colors.dark.accent : Colors.dark.gold}
                    />
                  </Pressable>
                ))}
              </ScrollView>
              <Pressable
                style={({ pressed }) => [styles.cancelBtn, pressed && { opacity: 0.7 }]}
                onPress={() => setShowExercisePicker(false)}
              >
                <Text style={styles.cancelText}>Cancel</Text>
              </Pressable>
            </View>
          ) : (
            <Pressable
              style={({ pressed }) => [styles.addExerciseBtn, pressed && { opacity: 0.85 }]}
              onPress={() => setShowExercisePicker(true)}
            >
              <Ionicons name="add" size={20} color={Colors.dark.gold} />
              <Text style={styles.addExerciseText}>Add Exercise</Text>
            </Pressable>
          )}

          {exercises.some(e => e.type === 'strength') && (
            <View style={styles.burnSection}>
              <Text style={styles.burnLabel}>Strength Calories Burned (optional)</Text>
              <TextInput
                style={styles.burnInput}
                placeholder="Auto-estimate from volume"
                placeholderTextColor={Colors.dark.textMuted}
                keyboardType="numeric"
                value={caloriesBurned}
                onChangeText={setCaloriesBurned}
              />
            </View>
          )}

          <View style={{ height: 120 }} />
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  title: {
    color: Colors.dark.text,
    fontSize: 24,
    fontFamily: 'Rubik_700Bold',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  cancelSessionBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.dark.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
  },
  finishBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.dark.success,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inactiveContent: {
    paddingHorizontal: 20,
    paddingBottom: 120,
  },
  startSection: {
    alignItems: 'center',
    paddingTop: 50,
    paddingBottom: 40,
    gap: 12,
  },
  startIconRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 4,
  },
  startTitle: {
    color: Colors.dark.text,
    fontSize: 22,
    fontFamily: 'Rubik_600SemiBold',
    marginTop: 8,
  },
  startSubtitle: {
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_400Regular',
    textAlign: 'center',
    maxWidth: 280,
  },
  startBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.dark.gold,
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 14,
    marginTop: 12,
  },
  startBtnText: {
    color: '#0A0A0F',
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
  },
  historySection: {
    marginTop: 20,
  },
  sectionTitle: {
    color: Colors.dark.text,
    fontSize: 18,
    fontFamily: 'Rubik_600SemiBold',
    marginBottom: 12,
  },
  historyCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  historyTitle: {
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_600SemiBold',
  },
  historyActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  historyActionBtn: {
    padding: 4,
  },
  historyBurn: {
    color: Colors.dark.caloriesBurn,
    fontSize: 14,
    fontFamily: 'Rubik_600SemiBold',
  },
  historyExercise: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  historyExRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  historyExName: {
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_400Regular',
  },
  historySets: {
    color: Colors.dark.textMuted,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
  },
  historyVolume: {
    color: Colors.dark.gold,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
    marginTop: 8,
  },
  activeContent: {
    paddingHorizontal: 20,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
  },
  statValue: {
    color: Colors.dark.gold,
    fontSize: 20,
    fontFamily: 'Rubik_700Bold',
  },
  statLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 11,
    fontFamily: 'Rubik_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  exerciseCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  cardioCard: {
    borderColor: Colors.dark.accent + '40',
  },
  exerciseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  exerciseNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  exerciseName: {
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
  },
  typeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  strengthBadge: {
    backgroundColor: Colors.dark.gold + '20',
  },
  cardioBadge: {
    backgroundColor: Colors.dark.accent + '20',
  },
  typeBadgeText: {
    fontSize: 10,
    fontFamily: 'Rubik_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  strengthBadgeText: {
    color: Colors.dark.gold,
  },
  cardioBadgeText: {
    color: Colors.dark.accent,
  },
  cardioFields: {
    flexDirection: 'row',
    gap: 10,
  },
  cardioField: {
    flex: 1,
    gap: 4,
  },
  cardioFieldLabel: {
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  cardioInput: {
    backgroundColor: Colors.dark.surfaceElevated,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 10,
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
    textAlign: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  cardioCalInput: {
    borderColor: Colors.dark.caloriesBurn + '40',
  },
  cardioCalOverride: {
    borderColor: Colors.dark.caloriesBurn,
    backgroundColor: Colors.dark.caloriesBurn + '15',
  },
  setHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  setHeaderText: {
    flex: 1,
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  setRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    gap: 8,
  },
  setNumber: {
    flex: 1,
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_500Medium',
    textAlign: 'center',
  },
  setInput: {
    flex: 1,
    backgroundColor: Colors.dark.surfaceElevated,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    color: Colors.dark.text,
    fontSize: 14,
    fontFamily: 'Rubik_400Regular',
    textAlign: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  addSetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingVertical: 8,
    marginTop: 4,
  },
  addSetText: {
    color: Colors.dark.accent,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
  },
  pickerCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  categoryTabs: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  categoryTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: Colors.dark.surfaceElevated,
  },
  categoryTabActive: {
    backgroundColor: Colors.dark.gold,
  },
  categoryTabActiveCardio: {
    backgroundColor: Colors.dark.accent,
  },
  categoryTabText: {
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_500Medium',
  },
  categoryTabTextActive: {
    color: '#0A0A0F',
  },
  customRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 10,
  },
  customAddBtn: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: Colors.dark.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  exerciseList: {
    maxHeight: 250,
  },
  exerciseOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  exerciseOptionRow: {
    flex: 1,
    gap: 2,
  },
  exerciseOptionText: {
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_400Regular',
  },
  exerciseOptionMeta: {
    color: Colors.dark.textMuted,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
  },
  cancelBtn: {
    alignItems: 'center',
    paddingVertical: 10,
    marginTop: 4,
  },
  cancelText: {
    color: Colors.dark.textMuted,
    fontSize: 14,
    fontFamily: 'Rubik_500Medium',
  },
  addExerciseBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: Colors.dark.gold,
    borderStyle: 'dashed',
    marginBottom: 16,
  },
  addExerciseText: {
    color: Colors.dark.gold,
    fontSize: 15,
    fontFamily: 'Rubik_500Medium',
  },
  burnSection: {
    marginBottom: 20,
  },
  burnLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
    marginBottom: 6,
  },
  burnInput: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_400Regular',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
});
