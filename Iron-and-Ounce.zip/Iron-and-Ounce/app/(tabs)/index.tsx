import React from 'react';
import { StyleSheet, Text, View, ScrollView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import CalorieRing from '@/components/CalorieRing';
import MacroBar from '@/components/MacroBar';
import HydrationCard from '@/components/HydrationCard';
import StreakBadge from '@/components/StreakBadge';
import { useData } from '@/lib/DataContext';

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const {
    profile, daily, streak, hydrationStreak,
    totalCaloriesConsumed, totalCaloriesBurned, remainingCalories,
    totalProtein, totalCarbs, totalFats, proteinGold, addWater,
  } = useData();

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + webTopInset + 16, paddingBottom: insets.bottom + 100 }]}
      showsVerticalScrollIndicator={false}
      contentInsetAdjustmentBehavior="automatic"
    >
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.greeting}>Burn to Earn</Text>
          <Text style={styles.dateText}>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</Text>
        </View>
        <StreakBadge count={streak} />
      </View>

      <View style={styles.ringSection}>
        <CalorieRing
          consumed={totalCaloriesConsumed}
          maintenance={profile.maintenanceCalories}
          burned={totalCaloriesBurned}
          size={220}
          strokeWidth={14}
        >
          <Text style={styles.ringCalories}>{remainingCalories}</Text>
          <Text style={styles.ringLabel}>remaining</Text>
        </CalorieRing>

        <View style={styles.calorieBreakdown}>
          <View style={styles.calorieItem}>
            <Ionicons name="restaurant" size={16} color={Colors.dark.calories} />
            <Text style={styles.calorieItemValue}>{totalCaloriesConsumed}</Text>
            <Text style={styles.calorieItemLabel}>consumed</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.calorieItem}>
            <Ionicons name="fitness" size={16} color={Colors.dark.caloriesBurn} />
            <Text style={styles.calorieItemValue}>+{totalCaloriesBurned}</Text>
            <Text style={styles.calorieItemLabel}>burned</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.calorieItem}>
            <Ionicons name="flag" size={16} color={Colors.dark.textSecondary} />
            <Text style={styles.calorieItemValue}>{profile.maintenanceCalories}</Text>
            <Text style={styles.calorieItemLabel}>goal</Text>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Macros</Text>
        <View style={styles.macroCard}>
          <MacroBar
            label="Protein"
            current={totalProtein}
            goal={profile.proteinGoal}
            color={Colors.dark.protein}
            isGold={proteinGold}
          />
          <MacroBar
            label="Carbs"
            current={totalCarbs}
            goal={profile.carbsGoal}
            color={Colors.dark.carbs}
          />
          <MacroBar
            label="Fats"
            current={totalFats}
            goal={profile.fatsGoal}
            color={Colors.dark.fats}
          />
        </View>
      </View>

      <View style={styles.section}>
        <HydrationCard
          currentOz={daily.waterOz}
          goalOz={profile.waterGoalOz}
          onAdd={addWater}
        />
        {hydrationStreak >= 3 && (
          <View style={styles.hydrationStreakRow}>
            <Ionicons name="trophy" size={16} color={Colors.dark.water} />
            <Text style={styles.hydrationStreakText}>{hydrationStreak} day hydration streak!</Text>
          </View>
        )}
      </View>

      {daily.workouts.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Training</Text>
          {daily.workouts.map(w => (
            <View key={w.id} style={styles.workoutSummaryCard}>
              <View style={styles.workoutSummaryRow}>
                <Ionicons name="barbell" size={18} color={Colors.dark.gold} />
                <Text style={styles.workoutSummaryText}>{w.exercises.length} exercises</Text>
              </View>
              <View style={styles.workoutStats}>
                <Text style={styles.workoutStat}>{w.totalVolume.toLocaleString()} lbs volume</Text>
                <Text style={styles.workoutStatBurn}>+{w.totalCaloriesBurned} kcal</Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  content: {
    paddingHorizontal: 20,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  greeting: {
    color: Colors.dark.gold,
    fontSize: 26,
    fontFamily: 'Rubik_700Bold',
    letterSpacing: -0.5,
  },
  dateText: {
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_400Regular',
    marginTop: 2,
  },
  ringSection: {
    alignItems: 'center',
    marginBottom: 28,
  },
  ringCalories: {
    color: Colors.dark.text,
    fontSize: 42,
    fontFamily: 'Rubik_700Bold',
    letterSpacing: -1,
  },
  ringLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
    marginTop: -2,
  },
  calorieBreakdown: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    gap: 16,
  },
  calorieItem: {
    alignItems: 'center',
    gap: 4,
  },
  calorieItemValue: {
    color: Colors.dark.text,
    fontSize: 18,
    fontFamily: 'Rubik_600SemiBold',
  },
  calorieItemLabel: {
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_400Regular',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  divider: {
    width: 1,
    height: 36,
    backgroundColor: Colors.dark.border,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: Colors.dark.text,
    fontSize: 18,
    fontFamily: 'Rubik_600SemiBold',
    marginBottom: 12,
  },
  macroCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  hydrationStreakRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 10,
    paddingHorizontal: 4,
  },
  hydrationStreakText: {
    color: Colors.dark.water,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
  },
  workoutSummaryCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginBottom: 8,
  },
  workoutSummaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  workoutSummaryText: {
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_500Medium',
  },
  workoutStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  workoutStat: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
  },
  workoutStatBurn: {
    color: Colors.dark.caloriesBurn,
    fontSize: 13,
    fontFamily: 'Rubik_600SemiBold',
  },
});
