import React, { useState, useCallback } from 'react';
import { StyleSheet, Text, View, ScrollView, Pressable, TextInput, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Svg, { Polyline, Line, Circle as SvgCircle } from 'react-native-svg';
import Colors from '@/constants/colors';
import { useData } from '@/lib/DataContext';
import { WeightEntry } from '@/lib/types';

function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

interface BadgeInfo {
  id: string;
  name: string;
  description: string;
  icon: string;
  iconSet: 'ionicons' | 'material';
  earned: boolean;
}

export default function ProgressScreen() {
  const insets = useSafeAreaInsets();
  const { profile, weightLog, streak, hydrationStreak, addWeightEntry, updateProfile } = useData();
  const [showWeightInput, setShowWeightInput] = useState(false);
  const [newWeight, setNewWeight] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [settingsCalories, setSettingsCalories] = useState(profile.maintenanceCalories.toString());
  const [settingsProtein, setSettingsProtein] = useState(profile.proteinGoal.toString());
  const [settingsCarbs, setSettingsCarbs] = useState(profile.carbsGoal.toString());
  const [settingsFats, setSettingsFats] = useState(profile.fatsGoal.toString());
  const [settingsWater, setSettingsWater] = useState(profile.waterGoalOz.toString());
  const [settingsGoalWeight, setSettingsGoalWeight] = useState(profile.goalWeight.toString());

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const weightLost = profile.startWeight - profile.currentWeight;
  const weightToGo = profile.currentWeight - profile.goalWeight;
  const progressPercent = Math.min(Math.max(weightLost / (profile.startWeight - profile.goalWeight), 0), 1);

  const milestones = Math.floor(weightLost / 5);

  const badges: BadgeInfo[] = [
    {
      id: 'warrior5', name: 'Weight Warrior I', description: 'Lost 5 lbs',
      icon: 'shield-checkmark', iconSet: 'ionicons', earned: weightLost >= 5,
    },
    {
      id: 'warrior10', name: 'Weight Warrior II', description: 'Lost 10 lbs',
      icon: 'shield-checkmark', iconSet: 'ionicons', earned: weightLost >= 10,
    },
    {
      id: 'warrior20', name: 'Weight Warrior III', description: 'Lost 20 lbs',
      icon: 'shield-checkmark', iconSet: 'ionicons', earned: weightLost >= 20,
    },
    {
      id: 'hydration', name: 'Hydration Hero', description: '7-day water streak',
      icon: 'water', iconSet: 'ionicons', earned: hydrationStreak >= 7,
    },
    {
      id: 'streak7', name: 'Week Warrior', description: '7-day logging streak',
      icon: 'flame', iconSet: 'ionicons', earned: streak >= 7,
    },
    {
      id: 'streak30', name: 'Iron Will', description: '30-day logging streak',
      icon: 'trophy', iconSet: 'ionicons', earned: streak >= 30,
    },
  ];

  const handleLogWeight = useCallback(async () => {
    const w = parseFloat(newWeight);
    if (isNaN(w) || w <= 0) return;
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    const entry: WeightEntry = {
      id: generateId(),
      weight: w,
      date: new Date().toISOString().split('T')[0],
      timestamp: Date.now(),
    };
    await addWeightEntry(entry);
    setNewWeight('');
    setShowWeightInput(false);
  }, [newWeight, addWeightEntry]);

  const handleSaveSettings = useCallback(async () => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await updateProfile({
      ...profile,
      maintenanceCalories: parseInt(settingsCalories) || profile.maintenanceCalories,
      proteinGoal: parseInt(settingsProtein) || profile.proteinGoal,
      carbsGoal: parseInt(settingsCarbs) || profile.carbsGoal,
      fatsGoal: parseInt(settingsFats) || profile.fatsGoal,
      waterGoalOz: parseInt(settingsWater) || profile.waterGoalOz,
      goalWeight: parseInt(settingsGoalWeight) || profile.goalWeight,
    });
    setShowSettings(false);
  }, [profile, settingsCalories, settingsProtein, settingsCarbs, settingsFats, settingsWater, settingsGoalWeight, updateProfile]);

  const chartWidth = 300;
  const chartHeight = 120;
  const recentWeights = weightLog.slice(-10);

  let chartPoints = '';
  if (recentWeights.length > 1) {
    const weights = recentWeights.map(w => w.weight);
    const minW = Math.min(...weights) - 2;
    const maxW = Math.max(...weights) + 2;
    const range = maxW - minW || 1;
    chartPoints = recentWeights.map((w, i) => {
      const x = (i / (recentWeights.length - 1)) * chartWidth;
      const y = chartHeight - ((w.weight - minW) / range) * chartHeight;
      return `${x},${y}`;
    }).join(' ');
  }

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + webTopInset + 16, paddingBottom: insets.bottom + 120 }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.headerRow}>
        <Text style={styles.title}>Progress</Text>
        <Pressable
          style={({ pressed }) => [styles.settingsBtn, pressed && { opacity: 0.7 }]}
          onPress={() => setShowSettings(!showSettings)}
        >
          <Ionicons name={showSettings ? 'close' : 'settings-outline'} size={22} color={Colors.dark.textSecondary} />
        </Pressable>
      </View>

      {showSettings ? (
        <View style={styles.settingsCard}>
          <Text style={styles.settingsSectionTitle}>Goals</Text>
          <View style={styles.settingsRow}>
            <Text style={styles.settingsLabel}>Daily Calories</Text>
            <TextInput
              style={styles.settingsInput}
              value={settingsCalories}
              onChangeText={setSettingsCalories}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.settingsRow}>
            <Text style={styles.settingsLabel}>Protein (g)</Text>
            <TextInput
              style={styles.settingsInput}
              value={settingsProtein}
              onChangeText={setSettingsProtein}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.settingsRow}>
            <Text style={styles.settingsLabel}>Carbs (g)</Text>
            <TextInput
              style={styles.settingsInput}
              value={settingsCarbs}
              onChangeText={setSettingsCarbs}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.settingsRow}>
            <Text style={styles.settingsLabel}>Fats (g)</Text>
            <TextInput
              style={styles.settingsInput}
              value={settingsFats}
              onChangeText={setSettingsFats}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.settingsRow}>
            <Text style={styles.settingsLabel}>Water (oz)</Text>
            <TextInput
              style={styles.settingsInput}
              value={settingsWater}
              onChangeText={setSettingsWater}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.settingsRow}>
            <Text style={styles.settingsLabel}>Goal Weight (lbs)</Text>
            <TextInput
              style={styles.settingsInput}
              value={settingsGoalWeight}
              onChangeText={setSettingsGoalWeight}
              keyboardType="numeric"
            />
          </View>
          <Pressable
            style={({ pressed }) => [styles.saveSettingsBtn, pressed && { opacity: 0.85 }]}
            onPress={handleSaveSettings}
          >
            <Ionicons name="checkmark" size={20} color="#0A0A0F" />
            <Text style={styles.saveSettingsBtnText}>Save Goals</Text>
          </Pressable>
        </View>
      ) : (
        <>
          <View style={styles.weightCard}>
            <View style={styles.weightHeader}>
              <View>
                <Text style={styles.weightLabel}>Current Weight</Text>
                <View style={styles.weightValueRow}>
                  <Text style={styles.weightValue}>{profile.currentWeight}</Text>
                  <Text style={styles.weightUnit}>lbs</Text>
                </View>
              </View>
              <Pressable
                style={({ pressed }) => [styles.logWeightBtn, pressed && { opacity: 0.85 }]}
                onPress={() => setShowWeightInput(!showWeightInput)}
              >
                <Ionicons name={showWeightInput ? 'close' : 'scale-outline'} size={20} color={Colors.dark.gold} />
              </Pressable>
            </View>

            {showWeightInput && (
              <View style={styles.weightInputRow}>
                <TextInput
                  style={styles.weightInput}
                  placeholder="Enter weight"
                  placeholderTextColor={Colors.dark.textMuted}
                  keyboardType="decimal-pad"
                  value={newWeight}
                  onChangeText={setNewWeight}
                />
                <Pressable
                  style={({ pressed }) => [styles.logBtn, pressed && { opacity: 0.85 }, !newWeight && { opacity: 0.4 }]}
                  onPress={handleLogWeight}
                  disabled={!newWeight}
                >
                  <Ionicons name="checkmark" size={18} color="#0A0A0F" />
                </Pressable>
              </View>
            )}

            <View style={styles.progressBar}>
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: `${progressPercent * 100}%` }]} />
              </View>
              <View style={styles.progressLabels}>
                <Text style={styles.progressLabel}>{profile.startWeight} lbs</Text>
                <Text style={styles.progressLabelGold}>{weightLost > 0 ? `-${weightLost} lbs` : 'Start'}</Text>
                <Text style={styles.progressLabel}>{profile.goalWeight} lbs</Text>
              </View>
            </View>

            <View style={styles.weightStats}>
              <View style={styles.weightStat}>
                <Text style={styles.weightStatValue}>{weightToGo > 0 ? weightToGo : 0}</Text>
                <Text style={styles.weightStatLabel}>lbs to go</Text>
              </View>
              <View style={styles.weightStat}>
                <Text style={styles.weightStatValue}>{milestones}</Text>
                <Text style={styles.weightStatLabel}>milestones</Text>
              </View>
              <View style={styles.weightStat}>
                <Text style={styles.weightStatValue}>{Math.round(progressPercent * 100)}%</Text>
                <Text style={styles.weightStatLabel}>progress</Text>
              </View>
            </View>
          </View>

          {recentWeights.length > 1 && (
            <View style={styles.chartCard}>
              <Text style={styles.chartTitle}>Weight Trend</Text>
              <View style={styles.chartContainer}>
                <Svg width={chartWidth} height={chartHeight + 10}>
                  <Line x1={0} y1={chartHeight / 2} x2={chartWidth} y2={chartHeight / 2} stroke={Colors.dark.border} strokeWidth={1} strokeDasharray="4,4" />
                  <Polyline
                    points={chartPoints}
                    fill="none"
                    stroke={Colors.dark.gold}
                    strokeWidth={2.5}
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                  {recentWeights.map((w, i) => {
                    const weights = recentWeights.map(e => e.weight);
                    const minW = Math.min(...weights) - 2;
                    const maxW = Math.max(...weights) + 2;
                    const range = maxW - minW || 1;
                    const x = (i / (recentWeights.length - 1)) * chartWidth;
                    const y = chartHeight - ((w.weight - minW) / range) * chartHeight;
                    return (
                      <SvgCircle key={w.id} cx={x} cy={y} r={4} fill={Colors.dark.gold} />
                    );
                  })}
                </Svg>
              </View>
              <View style={styles.chartLabels}>
                <Text style={styles.chartLabel}>{recentWeights[0]?.date?.slice(5)}</Text>
                <Text style={styles.chartLabel}>{recentWeights[recentWeights.length - 1]?.date?.slice(5)}</Text>
              </View>
            </View>
          )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Badges</Text>
            <View style={styles.badgeGrid}>
              {badges.map(badge => (
                <View key={badge.id} style={[styles.badgeCard, badge.earned && styles.badgeCardEarned]}>
                  <Ionicons
                    name={badge.icon as any}
                    size={28}
                    color={badge.earned ? Colors.dark.gold : Colors.dark.textMuted}
                  />
                  <Text style={[styles.badgeName, badge.earned && styles.badgeNameEarned]}>{badge.name}</Text>
                  <Text style={styles.badgeDesc}>{badge.description}</Text>
                </View>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Streaks</Text>
            <View style={styles.streakRow}>
              <View style={styles.streakCard}>
                <Ionicons name="flame" size={28} color={streak > 0 ? Colors.dark.streak : Colors.dark.textMuted} />
                <Text style={[styles.streakValue, streak > 0 && { color: Colors.dark.streak }]}>{streak}</Text>
                <Text style={styles.streakLabel}>Day Streak</Text>
              </View>
              <View style={styles.streakCard}>
                <Ionicons name="water" size={28} color={hydrationStreak > 0 ? Colors.dark.water : Colors.dark.textMuted} />
                <Text style={[styles.streakValue, hydrationStreak > 0 && { color: Colors.dark.water }]}>{hydrationStreak}</Text>
                <Text style={styles.streakLabel}>Hydration</Text>
              </View>
            </View>
          </View>
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  content: {
    paddingHorizontal: 20,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    color: Colors.dark.text,
    fontSize: 24,
    fontFamily: 'Rubik_700Bold',
  },
  settingsBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.dark.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingsCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  settingsSectionTitle: {
    color: Colors.dark.gold,
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
    marginBottom: 16,
  },
  settingsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  settingsLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 14,
    fontFamily: 'Rubik_400Regular',
  },
  settingsInput: {
    backgroundColor: Colors.dark.surfaceElevated,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 8,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: 'Rubik_500Medium',
    width: 100,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  saveSettingsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.dark.gold,
    borderRadius: 12,
    paddingVertical: 14,
    marginTop: 8,
  },
  saveSettingsBtnText: {
    color: '#0A0A0F',
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
  },
  weightCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    padding: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  weightHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  weightLabel: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
    marginBottom: 4,
  },
  weightValueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
  },
  weightValue: {
    color: Colors.dark.text,
    fontSize: 38,
    fontFamily: 'Rubik_700Bold',
  },
  weightUnit: {
    color: Colors.dark.textMuted,
    fontSize: 16,
    fontFamily: 'Rubik_400Regular',
  },
  logWeightBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.dark.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  weightInputRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  weightInput: {
    flex: 1,
    backgroundColor: Colors.dark.surfaceElevated,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: 'Rubik_400Regular',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  logBtn: {
    width: 42,
    height: 42,
    borderRadius: 10,
    backgroundColor: Colors.dark.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressBar: {
    marginBottom: 16,
  },
  progressBarBg: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.dark.surfaceElevated,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
    backgroundColor: Colors.dark.gold,
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressLabel: {
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_400Regular',
  },
  progressLabelGold: {
    color: Colors.dark.gold,
    fontSize: 11,
    fontFamily: 'Rubik_600SemiBold',
  },
  weightStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  weightStat: {
    alignItems: 'center',
  },
  weightStatValue: {
    color: Colors.dark.text,
    fontSize: 22,
    fontFamily: 'Rubik_700Bold',
  },
  weightStatLabel: {
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_400Regular',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginTop: 2,
  },
  chartCard: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    padding: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  chartTitle: {
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
    marginBottom: 12,
  },
  chartContainer: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  chartLabel: {
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_400Regular',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: Colors.dark.text,
    fontSize: 18,
    fontFamily: 'Rubik_600SemiBold',
    marginBottom: 14,
  },
  badgeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  badgeCard: {
    width: '47%',
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    opacity: 0.5,
  },
  badgeCardEarned: {
    opacity: 1,
    borderColor: Colors.dark.gold,
  },
  badgeName: {
    color: Colors.dark.textMuted,
    fontSize: 13,
    fontFamily: 'Rubik_600SemiBold',
    textAlign: 'center',
  },
  badgeNameEarned: {
    color: Colors.dark.gold,
  },
  badgeDesc: {
    color: Colors.dark.textMuted,
    fontSize: 11,
    fontFamily: 'Rubik_400Regular',
    textAlign: 'center',
  },
  streakRow: {
    flexDirection: 'row',
    gap: 12,
  },
  streakCard: {
    flex: 1,
    backgroundColor: Colors.dark.surface,
    borderRadius: 14,
    padding: 18,
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  streakValue: {
    color: Colors.dark.textMuted,
    fontSize: 28,
    fontFamily: 'Rubik_700Bold',
  },
  streakLabel: {
    color: Colors.dark.textMuted,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
  },
});
