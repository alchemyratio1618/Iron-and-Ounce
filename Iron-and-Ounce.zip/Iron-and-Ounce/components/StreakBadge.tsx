import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';

interface StreakBadgeProps {
  count: number;
  label?: string;
}

export default function StreakBadge({ count, label = 'Day Streak' }: StreakBadgeProps) {
  return (
    <View style={styles.container}>
      <Ionicons name="flame" size={22} color={count > 0 ? Colors.dark.streak : Colors.dark.textMuted} />
      <Text style={[styles.count, count > 0 && styles.countActive]}>{count}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.dark.surface,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  count: {
    color: Colors.dark.textMuted,
    fontSize: 16,
    fontFamily: 'Rubik_700Bold',
  },
  countActive: {
    color: Colors.dark.streak,
  },
  label: {
    color: Colors.dark.textSecondary,
    fontSize: 12,
    fontFamily: 'Rubik_400Regular',
  },
});
