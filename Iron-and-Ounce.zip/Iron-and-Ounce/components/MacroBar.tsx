import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '@/constants/colors';

interface MacroBarProps {
  label: string;
  current: number;
  goal: number;
  color: string;
  unit?: string;
  isGold?: boolean;
}

export default function MacroBar({ label, current, goal, color, unit = 'g', isGold }: MacroBarProps) {
  const progress = Math.min(current / goal, 1);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.labelRow}>
          <Text style={[styles.label, isGold && styles.goldLabel]}>{label}</Text>
          {isGold && <View style={styles.goldBadge}><Text style={styles.goldBadgeText}>GOLD</Text></View>}
        </View>
        <Text style={styles.values}>{current}{unit} / {goal}{unit}</Text>
      </View>
      <View style={styles.barBg}>
        <View style={[styles.barFill, { backgroundColor: color, width: `${progress * 100}%` }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  labelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  label: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_500Medium',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  goldLabel: {
    color: Colors.dark.gold,
  },
  goldBadge: {
    backgroundColor: Colors.dark.gold,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  goldBadgeText: {
    color: '#0A0A0F',
    fontSize: 9,
    fontFamily: 'Rubik_700Bold',
    letterSpacing: 1,
  },
  values: {
    color: Colors.dark.text,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
  },
  barBg: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.dark.surfaceElevated,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: 4,
  },
});
