import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';

interface HydrationCardProps {
  currentOz: number;
  goalOz: number;
  onAdd: (oz: number) => void;
}

export default function HydrationCard({ currentOz, goalOz, onAdd }: HydrationCardProps) {
  const progress = Math.min(currentOz / goalOz, 1);
  const remaining = Math.max(goalOz - currentOz, 0);

  const handlePress = (oz: number) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onAdd(oz);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <Ionicons name="water" size={20} color={Colors.dark.water} />
          <Text style={styles.title}>Hydration</Text>
        </View>
        <Text style={styles.remaining}>{remaining}oz to go</Text>
      </View>

      <View style={styles.progressRow}>
        <Text style={styles.currentValue}>{currentOz}</Text>
        <Text style={styles.unit}>oz</Text>
        <Text style={styles.separator}>/</Text>
        <Text style={styles.goalValue}>{goalOz}oz</Text>
      </View>

      <View style={styles.barBg}>
        <View style={[styles.barFill, { width: `${progress * 100}%` }]} />
      </View>

      <View style={styles.buttons}>
        {[8, 16, 24].map(oz => (
          <Pressable
            key={oz}
            style={({ pressed }) => [styles.addBtn, pressed && styles.addBtnPressed]}
            onPress={() => handlePress(oz)}
          >
            <Ionicons name="add" size={16} color={Colors.dark.water} />
            <Text style={styles.addBtnText}>{oz}oz</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.dark.surface,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: 'Rubik_600SemiBold',
  },
  remaining: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: 'Rubik_400Regular',
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 10,
    gap: 2,
  },
  currentValue: {
    color: Colors.dark.water,
    fontSize: 32,
    fontFamily: 'Rubik_700Bold',
  },
  unit: {
    color: Colors.dark.waterDark,
    fontSize: 16,
    fontFamily: 'Rubik_500Medium',
  },
  separator: {
    color: Colors.dark.textMuted,
    fontSize: 18,
    marginHorizontal: 4,
  },
  goalValue: {
    color: Colors.dark.textSecondary,
    fontSize: 16,
    fontFamily: 'Rubik_400Regular',
  },
  barBg: {
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.dark.surfaceElevated,
    overflow: 'hidden',
    marginBottom: 14,
  },
  barFill: {
    height: '100%',
    borderRadius: 3,
    backgroundColor: Colors.dark.water,
  },
  buttons: {
    flexDirection: 'row',
    gap: 10,
  },
  addBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: Colors.dark.surfaceElevated,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  addBtnPressed: {
    backgroundColor: Colors.dark.surfaceHighlight,
    transform: [{ scale: 0.97 }],
  },
  addBtnText: {
    color: Colors.dark.water,
    fontSize: 14,
    fontFamily: 'Rubik_500Medium',
  },
});
