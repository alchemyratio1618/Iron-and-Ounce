export interface MacroEntry {
  protein: number;
  carbs: number;
  fats: number;
  calories: number;
}

export interface FoodEntry {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  timestamp: number;
}

export type ExerciseType = 'strength' | 'cardio';

export interface ExerciseSet {
  reps: number;
  weight: number;
}

export interface ExerciseEntry {
  id: string;
  name: string;
  type: ExerciseType;
  sets: ExerciseSet[];
  durationMin?: number;
  caloriesBurned: number;
  timestamp: number;
}

export interface WorkoutSession {
  id: string;
  date: string;
  exercises: ExerciseEntry[];
  totalVolume: number;
  totalCaloriesBurned: number;
}

export interface WeightEntry {
  id: string;
  weight: number;
  date: string;
  timestamp: number;
}

export interface DailyData {
  date: string;
  foods: FoodEntry[];
  workouts: WorkoutSession[];
  waterOz: number;
  logged: boolean;
}

export interface UserProfile {
  maintenanceCalories: number;
  proteinGoal: number;
  carbsGoal: number;
  fatsGoal: number;
  waterGoalOz: number;
  currentWeight: number;
  goalWeight: number;
  startWeight: number;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: string;
}

export const DEFAULT_PROFILE: UserProfile = {
  maintenanceCalories: 0,
  proteinGoal: 0,
  carbsGoal: 0,
  fatsGoal: 0,
  waterGoalOz: 0,
  currentWeight: 0,
  goalWeight: 0,
  startWeight: 0,
};

export const COMMON_FOODS: { name: string; calories: number; protein: number; carbs: number; fats: number }[] = [
  { name: 'Chicken Breast (6oz)', calories: 280, protein: 52, carbs: 0, fats: 6 },
  { name: 'Salmon Fillet (6oz)', calories: 350, protein: 40, carbs: 0, fats: 20 },
  { name: 'Eggs (2 large)', calories: 140, protein: 12, carbs: 1, fats: 10 },
  { name: 'Greek Yogurt (1 cup)', calories: 130, protein: 22, carbs: 8, fats: 0 },
  { name: 'Protein Shake', calories: 150, protein: 30, carbs: 5, fats: 2 },
  { name: 'Rice (1 cup cooked)', calories: 205, protein: 4, carbs: 45, fats: 0 },
  { name: 'Sweet Potato (medium)', calories: 103, protein: 2, carbs: 24, fats: 0 },
  { name: 'Broccoli (1 cup)', calories: 55, protein: 4, carbs: 11, fats: 0 },
  { name: 'Oatmeal (1 cup)', calories: 150, protein: 5, carbs: 27, fats: 3 },
  { name: 'Almonds (1oz)', calories: 164, protein: 6, carbs: 6, fats: 14 },
  { name: 'Banana', calories: 105, protein: 1, carbs: 27, fats: 0 },
  { name: 'Avocado (half)', calories: 160, protein: 2, carbs: 9, fats: 15 },
  { name: 'Steak (6oz)', calories: 375, protein: 46, carbs: 0, fats: 20 },
  { name: 'Turkey Breast (6oz)', calories: 250, protein: 50, carbs: 0, fats: 4 },
  { name: 'Cottage Cheese (1 cup)', calories: 220, protein: 28, carbs: 8, fats: 9 },
  { name: 'Tuna Can (5oz)', calories: 120, protein: 27, carbs: 0, fats: 1 },
  { name: 'Peanut Butter (2 tbsp)', calories: 190, protein: 7, carbs: 7, fats: 16 },
  { name: 'Whole Wheat Bread (2 slices)', calories: 160, protein: 8, carbs: 28, fats: 2 },
];

export interface ExerciseCatalogItem {
  name: string;
  type: ExerciseType;
  caloriesPerMin?: number;
}

export const STRENGTH_EXERCISES: ExerciseCatalogItem[] = [
  { name: 'Bench Press', type: 'strength' },
  { name: 'Squat', type: 'strength' },
  { name: 'Deadlift', type: 'strength' },
  { name: 'Overhead Press', type: 'strength' },
  { name: 'Barbell Row', type: 'strength' },
  { name: 'Pull-ups', type: 'strength' },
  { name: 'Dumbbell Curl', type: 'strength' },
  { name: 'Tricep Extension', type: 'strength' },
  { name: 'Leg Press', type: 'strength' },
  { name: 'Lateral Raise', type: 'strength' },
  { name: 'Lat Pulldown', type: 'strength' },
  { name: 'Cable Fly', type: 'strength' },
  { name: 'Romanian Deadlift', type: 'strength' },
  { name: 'Lunges', type: 'strength' },
  { name: 'Calf Raises', type: 'strength' },
];

export const CARDIO_EXERCISES: ExerciseCatalogItem[] = [
  { name: 'Running', type: 'cardio', caloriesPerMin: 12 },
  { name: 'Treadmill', type: 'cardio', caloriesPerMin: 10 },
  { name: 'Elliptical', type: 'cardio', caloriesPerMin: 8 },
  { name: 'Standing Bike', type: 'cardio', caloriesPerMin: 7 },
  { name: 'Stairmaster', type: 'cardio', caloriesPerMin: 11 },
  { name: 'Rowing Machine', type: 'cardio', caloriesPerMin: 9 },
  { name: 'Jump Rope', type: 'cardio', caloriesPerMin: 13 },
  { name: 'Walking', type: 'cardio', caloriesPerMin: 5 },
];

export const ALL_EXERCISES: ExerciseCatalogItem[] = [...STRENGTH_EXERCISES, ...CARDIO_EXERCISES];

export const COMMON_EXERCISES = STRENGTH_EXERCISES.map(e => e.name);
