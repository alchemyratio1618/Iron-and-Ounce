import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import { DailyData, UserProfile, WeightEntry, FoodEntry, WorkoutSession, DEFAULT_PROFILE } from './types';
import * as Storage from './storage';

interface DataContextValue {
  profile: UserProfile;
  daily: DailyData;
  weightLog: WeightEntry[];
  streak: number;
  hydrationStreak: number;
  loading: boolean;
  onboardingComplete: boolean;
  totalCaloriesConsumed: number;
  totalCaloriesBurned: number;
  remainingCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFats: number;
  proteinGold: boolean;
  addFood: (food: FoodEntry) => Promise<void>;
  removeFood: (id: string) => Promise<void>;
  addWater: (oz: number) => Promise<void>;
  addWorkout: (workout: WorkoutSession) => Promise<void>;
  removeWorkout: (id: string) => Promise<void>;
  updateWorkout: (workout: WorkoutSession) => Promise<void>;
  addWeightEntry: (entry: WeightEntry) => Promise<void>;
  updateProfile: (profile: UserProfile) => Promise<void>;
  completeOnboarding: (profile: UserProfile) => Promise<void>;
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextValue | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [daily, setDaily] = useState<DailyData>({ date: '', foods: [], workouts: [], waterOz: 0, logged: false });
  const [weightLog, setWeightLog] = useState<WeightEntry[]>([]);
  const [streak, setStreak] = useState(0);
  const [hydrationStreak, setHydrationStreak] = useState(0);
  const [loading, setLoading] = useState(true);
  const [onboardingComplete, setOnboardingComplete] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [p, d, w, s, hs, onboarded] = await Promise.all([
        Storage.getProfile(),
        Storage.getDailyData(),
        Storage.getWeightLog(),
        Storage.getStreak(),
        Storage.getHydrationStreak(),
        Storage.isOnboardingComplete(),
      ]);
      setProfile(p);
      setDaily(d);
      setWeightLog(w);
      setStreak(s);
      setHydrationStreak(hs);
      setOnboardingComplete(onboarded);
    } catch (e) {
      console.error('Failed to load data:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const totalCaloriesConsumed = useMemo(() =>
    daily.foods.reduce((sum, f) => sum + f.calories, 0), [daily.foods]);

  const totalCaloriesBurned = useMemo(() =>
    daily.workouts.reduce((sum, w) => sum + w.totalCaloriesBurned, 0), [daily.workouts]);

  const remainingCalories = useMemo(() =>
    (profile.maintenanceCalories - totalCaloriesConsumed) + totalCaloriesBurned,
    [profile.maintenanceCalories, totalCaloriesConsumed, totalCaloriesBurned]);

  const totalProtein = useMemo(() =>
    daily.foods.reduce((sum, f) => sum + f.protein, 0), [daily.foods]);

  const totalCarbs = useMemo(() =>
    daily.foods.reduce((sum, f) => sum + f.carbs, 0), [daily.foods]);

  const totalFats = useMemo(() =>
    daily.foods.reduce((sum, f) => sum + f.fats, 0), [daily.foods]);

  const proteinGold = totalProtein >= 100;

  const addFood = useCallback(async (food: FoodEntry) => {
    const updated = { ...daily, foods: [...daily.foods, food], logged: true };
    setDaily(updated);
    await Storage.saveDailyData(updated);
    await Storage.updateStreak(true);
    const s = await Storage.getStreak();
    setStreak(s);
  }, [daily]);

  const removeFood = useCallback(async (id: string) => {
    const updated = { ...daily, foods: daily.foods.filter(f => f.id !== id) };
    setDaily(updated);
    await Storage.saveDailyData(updated);
  }, [daily]);

  const addWater = useCallback(async (oz: number) => {
    const updated = { ...daily, waterOz: daily.waterOz + oz, logged: true };
    setDaily(updated);
    await Storage.saveDailyData(updated);
    if (updated.waterOz >= profile.waterGoalOz) {
      const hs = await Storage.updateHydrationStreak(true);
      setHydrationStreak(hs);
    }
  }, [daily, profile.waterGoalOz]);

  const addWorkout = useCallback(async (workout: WorkoutSession) => {
    const updated = { ...daily, workouts: [...daily.workouts, workout], logged: true };
    setDaily(updated);
    await Storage.saveDailyData(updated);
    await Storage.updateStreak(true);
    const s = await Storage.getStreak();
    setStreak(s);
  }, [daily]);

  const removeWorkout = useCallback(async (id: string) => {
    const updated = { ...daily, workouts: daily.workouts.filter(w => w.id !== id) };
    setDaily(updated);
    await Storage.saveDailyData(updated);
  }, [daily]);

  const updateWorkout = useCallback(async (workout: WorkoutSession) => {
    const updated = { ...daily, workouts: daily.workouts.map(w => w.id === workout.id ? workout : w) };
    setDaily(updated);
    await Storage.saveDailyData(updated);
  }, [daily]);

  const addWeightEntry = useCallback(async (entry: WeightEntry) => {
    await Storage.saveWeightEntry(entry);
    const w = await Storage.getWeightLog();
    setWeightLog(w);
    const updatedProfile = { ...profile, currentWeight: entry.weight };
    setProfile(updatedProfile);
    await Storage.saveProfile(updatedProfile);
  }, [profile]);

  const updateProfile = useCallback(async (newProfile: UserProfile) => {
    setProfile(newProfile);
    await Storage.saveProfile(newProfile);
  }, []);

  const completeOnboarding = useCallback(async (newProfile: UserProfile) => {
    setProfile(newProfile);
    await Storage.saveProfile(newProfile);
    await Storage.setOnboardingComplete();
    setOnboardingComplete(true);
  }, []);

  const value = useMemo(() => ({
    profile, daily, weightLog, streak, hydrationStreak, loading, onboardingComplete,
    totalCaloriesConsumed, totalCaloriesBurned, remainingCalories,
    totalProtein, totalCarbs, totalFats, proteinGold,
    addFood, removeFood, addWater, addWorkout, removeWorkout, updateWorkout,
    addWeightEntry, updateProfile, completeOnboarding, refreshData: loadData,
  }), [profile, daily, weightLog, streak, hydrationStreak, loading, onboardingComplete,
    totalCaloriesConsumed, totalCaloriesBurned, remainingCalories,
    totalProtein, totalCarbs, totalFats, proteinGold,
    addFood, removeFood, addWater, addWorkout, removeWorkout, updateWorkout,
    addWeightEntry, updateProfile, completeOnboarding, loadData]);

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
}
