import AsyncStorage from '@react-native-async-storage/async-storage';
import { DailyData, UserProfile, WeightEntry, DEFAULT_PROFILE } from './types';

const KEYS = {
  PROFILE: '@iron_ounce_profile',
  DAILY_PREFIX: '@iron_ounce_daily_',
  WEIGHT_LOG: '@iron_ounce_weight_log',
  STREAK: '@iron_ounce_streak',
  BADGES: '@iron_ounce_badges',
  HYDRATION_STREAK: '@iron_ounce_hydration_streak',
  ONBOARDING_COMPLETE: '@iron_ounce_onboarding_complete',
};

function getTodayKey(): string {
  return new Date().toISOString().split('T')[0];
}

export async function getProfile(): Promise<UserProfile> {
  const data = await AsyncStorage.getItem(KEYS.PROFILE);
  if (data) return JSON.parse(data);
  return DEFAULT_PROFILE;
}

export async function saveProfile(profile: UserProfile): Promise<void> {
  await AsyncStorage.setItem(KEYS.PROFILE, JSON.stringify(profile));
}

export async function getDailyData(date?: string): Promise<DailyData> {
  const key = date || getTodayKey();
  const data = await AsyncStorage.getItem(KEYS.DAILY_PREFIX + key);
  if (data) return JSON.parse(data);
  return { date: key, foods: [], workouts: [], waterOz: 0, logged: false };
}

export async function saveDailyData(daily: DailyData): Promise<void> {
  await AsyncStorage.setItem(KEYS.DAILY_PREFIX + daily.date, JSON.stringify(daily));
}

export async function getWeightLog(): Promise<WeightEntry[]> {
  const data = await AsyncStorage.getItem(KEYS.WEIGHT_LOG);
  if (data) return JSON.parse(data);
  return [];
}

export async function saveWeightEntry(entry: WeightEntry): Promise<void> {
  const log = await getWeightLog();
  log.push(entry);
  await AsyncStorage.setItem(KEYS.WEIGHT_LOG, JSON.stringify(log));
}

export async function getStreak(): Promise<number> {
  const data = await AsyncStorage.getItem(KEYS.STREAK);
  if (data) return JSON.parse(data).count || 0;
  return 0;
}

export async function updateStreak(logged: boolean): Promise<number> {
  const current = await getStreak();
  const lastDate = await AsyncStorage.getItem(KEYS.STREAK + '_last');
  const today = getTodayKey();

  if (lastDate === today) return current;

  if (logged) {
    const newCount = current + 1;
    await AsyncStorage.setItem(KEYS.STREAK, JSON.stringify({ count: newCount }));
    await AsyncStorage.setItem(KEYS.STREAK + '_last', today);
    return newCount;
  }
  return current;
}

export async function getHydrationStreak(): Promise<number> {
  const data = await AsyncStorage.getItem(KEYS.HYDRATION_STREAK);
  if (data) return JSON.parse(data).count || 0;
  return 0;
}

export async function updateHydrationStreak(metGoal: boolean): Promise<number> {
  const current = await getHydrationStreak();
  const lastDate = await AsyncStorage.getItem(KEYS.HYDRATION_STREAK + '_last');
  const today = getTodayKey();

  if (lastDate === today) return current;

  if (metGoal) {
    const newCount = current + 1;
    await AsyncStorage.setItem(KEYS.HYDRATION_STREAK, JSON.stringify({ count: newCount }));
    await AsyncStorage.setItem(KEYS.HYDRATION_STREAK + '_last', today);
    return newCount;
  } else {
    await AsyncStorage.setItem(KEYS.HYDRATION_STREAK, JSON.stringify({ count: 0 }));
    return 0;
  }
}

export async function isOnboardingComplete(): Promise<boolean> {
  const data = await AsyncStorage.getItem(KEYS.ONBOARDING_COMPLETE);
  return data === 'true';
}

export async function setOnboardingComplete(): Promise<void> {
  await AsyncStorage.setItem(KEYS.ONBOARDING_COMPLETE, 'true');
}
